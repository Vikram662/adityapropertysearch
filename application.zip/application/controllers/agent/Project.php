<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends CI_Controller {

	public function index()
	{
		$data['view'] = 'agent/project/list';
		$this->load->view('agent/layout', $data, FALSE);	
	}

}

/* End of file Project.php */
/* Location: ./application/controllers/agent/Project.php */